// This is a Draft Page
import 'package:flutter/material.dart';
import 'register.dart';
import 'dart:io';
import 'frontpage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';

final FirebaseAuth _auth = FirebaseAuth.instance;

class LoginPage extends StatefulWidget {
	LoginPage({Key key}) : super(key : key);
	@override
	State<StatefulWidget> createState() => LoginPageState();
}

class LoginPageState extends State<LoginPage> {
	@override
	Widget build(BuildContext context) {
		return Scaffold(
			backgroundColor: Colors.black,
			body: Builder(builder: (BuildContext context) {
				return ListView(
					scrollDirection: Axis.vertical,
					children: <Widget>[
						_EmailPasswordForm(),
					],
					);
				}),
			);
	}

}

class _EmailPasswordForm extends StatefulWidget {
	@override
	State<StatefulWidget> createState() => _EmailPasswordFormState();
}

class _EmailPasswordFormState extends State<_EmailPasswordForm> {
	TextStyle style = TextStyle(fontSize: 20.0),

	final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
	final TextEditingController _emailController = TextEditingController();
	final TextEditingController _passwordController = TextEditingController();

	bool _success;
	String _userEmail;
	@override
	Widget build(BuildContext context) {
		return Form(
			key: _formKey,
			child: Column(
				crossAxisAlignment: CrossAxisAlignment.start,
				children: <Widget>[
					SizedBox(
						height: 100.0,
						width: 250.0,
						child: Image.assets("assets/original.png", fit: BoxFit.contain,),
						),

					SizedBox(height: 40.0),

					TextFormField(
						controller: _emailController,
						elevation: 5.0,
						style: style,
						obscureText: false,
						decoration: new InputDecoration(
							filled: true,
							fillColor: Colors.white,
							contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
							hintText: "Email",
							border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
							),
						validator: (value) => value.isEmpty ? "Email is required" : null,
						//onSaved: (value) => _emailController = value.trim(),
						),

					SizedBox(height: 25.0),

					TextFormField(
						controller: _passwordController,
						elevation: 5.0,
						style: style,
						obscureText: true,
						decoration: new InputDecoration(
							filled: true,
							fillColor: Colors.white,
							contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
							hintText: "Password",
							border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
							),
						validator: (value) => value.isEmpt ? "Password is Required" : null,
						//onSaved: (value) => _passwordController = value.trim(),
						),

					SizedBox(height: 10.0),
					SizedBox(height: 50.0, child: Text("Forgot your Password?", style: TextStyle(color: Colors.white, fontSize: 18.0))),

					Material(
						elevation: 5.0,
						borderRadius: BorderRadius.circular(20.0),
						color: Colors.red,
						child: MaterialButton(
							minWidth: MediaQuery.of(context).size.width,
							padding: const EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
							onPressed: () {},
							child: Text(
								"Login",
								textAlign: TextAlign.center,
								style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
								),
							),
						),

					SizedBox(height: 35.0),
					SizedBox(height: 20.0, child: Text("Don't have an account", style: TextStyle(color: Colors.white))),

					Material(
						elevation: 5.0,
						borderRadius: BorderRadius.circular(20.0),
						color: Colors.red,
						child: MaterialButton(
							minWidth: MediaQuery.of(context).size.width,
							padding: const EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
							onPressed: () {},
							child: Text(
								"Create account",
								textAlign: TextAlign.center,
								style: TextAlign(color: Colors.white, fontWeigth: FontWeight.bold),
								),
							),
						),

					SizedBox(height: 15.0),
				],
				),
			);
	}
}
