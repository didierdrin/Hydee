// Front Page
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'login.dart';
// arcore plugins 
import 'package:arcore_flutter_plugin/arcore_flutter_plugin.dart';
import 'package:vector_math/vector_math_64.dart' as vector;

final FirebaseAuth _auth = FirebaseAuth.instance;

class FrontPage extends StatefulWidget {
  //FrontPage({Key key}) : super(key : key);
  @override
  State<StatefulWidget> createState() => FrontPageState();
}

class FrontPageState extends State<FrontPage> {
  ArCoreController arCoreController;

  _onArCoreViewCreated(ArCoreController _arcoreController) {
    arCoreController = _arcoreController;
    _addSphere(arCoreController);
  }
  
  _addCube(arCoreController _arcorecontroller) {
      final material = ArCoreMaterial(
        color: Color.fromARGB(120, 66, 134, 244),
        metallic: 1.0,
        );
      final cube = ArCoreCube(
        materials: [material],
        size: vector.Vector3(0.5, 0.5, 0.5),
        );
      final node = ArCoreNode(
        shape: cube,
        position: vector.Vector3(-0.5, 0.5, -3.5),
        );
      controller.add(node);
    };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('hydee'),
        centerTitle: true,
        actions: <Widget>[
          IconButton(
              icon: Icon(Icons.exit_to_app),
              onPressed: () async {
                final FirebaseUser user = await _auth.currentUser();
                if (user == null) {
                  Scaffold.of(context).showSnackBar(const SnackBar(
                    content: Text("You're not Signed In"),
                  ));
                  return;
                }
                _signOut();
                Scaffold.of(context).showSnackBar(SnackBar(
                  content: Text("Successfully signed out"),
                ));
              },),
        ],
      ),

      drawer: Drawer(),
      body: ArCoreView(
        onArCoreViewCreated: _onArCoreViewCreated,
        ),
    );
  }
  /*
  void _onArCoreViewCreated(ArCoreController controller) {
    arCoreController = controller;

    _addCube(arCoreController controller) {
      final material = ArCoreMaterial(
        color: Color.fromARGB(120, 66, 134, 244),
        metallic: 1.0,
        );
      final cube = ArCoreCube(
        materials: [material],
        size: vector.Vector3(0.5, 0.5, 0.5),
        );
      final node = ArCoreNode(
        shape: cube,
        position: vector.Vector3(-0.5, 0.5, -3.5),
        );
      controller.add(node);
    }
  } */

  void _signOut() async {
    await _auth.signOut();
    _pushPage(context, LoginPage());
  }

  void _pushPage(BuildContext context, page) {
  	Navigator.of(context).pushReplacement(
  		MaterialPageRoute<void>(builder: (_) => page),
  		);
  } 
  @override
  void dispose() {
    arCoreController.dispose();
    super.dispose();
  } 
}
