// This is a Draft Page
import 'package:flutter/material.dart';
import 'login.dart';
import 'dart:io';
import 'dart:async';
import 'frontpage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';

final FirebaseAuth _auth = FirebaseAuth.instance;

class RegisterPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => RegisterPageState();
}

class RegisterPageState extends State<RegisterPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Builder(builder: (BuildContext context) {
        return ListView(
          scrollDirection: Axis.vertical,
          children: <Widget>[
            _EmailPasswordForm(),
          ],
        );
      }),
    );
  }
}

class _EmailPasswordForm extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => _EmailPasswordFormState();
}

class _EmailPasswordFormState extends State<_EmailPasswordForm> {
  TextStyle style = TextStyle(fontSize: 20.0);

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _success;
  String _userEmail;
  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            padding: EdgeInsets.fromLTRB(100, 20, 0, 0),
            height: 100.0,
            width: 250.0,
            child: Image.asset(
              "assets/original.png",
              fit: BoxFit.contain,
            ),
          ),
          SizedBox(height: 40.0),
          TextFormField(
            controller: _emailController,
            style: style,
            obscureText: false,
            decoration: new InputDecoration(
              filled: true,
              fillColor: Colors.white,
              contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
              hintText: "Email",
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
            ),
            validator: (value) => value.isEmpty ? "Email is required" : null,
            //onSaved: (value) => _emailController = value.trim(),
          ),
          SizedBox(height: 25.0),
          TextFormField(
            controller: _passwordController,
            style: style,
            obscureText: true,
            decoration: new InputDecoration(
              filled: true,
              fillColor: Colors.white,
              contentPadding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
              hintText: "Password",
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
            ),
            validator: (value) => value.isEmpty ? "Password is Required" : null,
            //onSaved: (value) => _passwordController = value.trim(),
          ),
          SizedBox(height: 10.0),
          /*
          Container(
              padding: EdgeInsets.fromLTRB(40, 0, 0, 0),
              height: 50.0,
              child: Text("Forgot your Password?",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 18.0))), */
          SizedBox(height: 20.0,),
          Material(
            elevation: 5.0,
            borderRadius: BorderRadius.circular(20.0),
            color: Colors.red,
            child: MaterialButton(
              minWidth: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
              onPressed: () async {
                if (_formKey.currentState.validate()) {
                  _register();
                  }
                },
              child: Text(
                "Create Account",
                textAlign: TextAlign.center,
                style:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          SizedBox(height: 30.0,),
          Container(
            padding: const EdgeInsets.fromLTRB(40, 0, 0, 0),
              height: 20.0,
              child: Text("Have an account?",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 18.0))),
          SizedBox(height: 20),
          Material(
            elevation: 5.0,
            borderRadius: BorderRadius.circular(20.0),
            color: Colors.red,
            child: MaterialButton(
              minWidth: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
              onPressed: () => _pushPage(context, LoginPage()),
              child: Text(
                "Login",
                textAlign: TextAlign.center,
                style:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          SizedBox(height: 15.0),
        ],
      ),
    );
  }

  void _pushPage(BuildContext context, page) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => page),
    );
  }
  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _register() async {
    final FirebaseUser user = (await _auth.createUserWithEmailAndPassword(email: _emailController.text, password: _passwordController.text,)).user;
    if (user != null) {
      setState(() {
        _success = true;
        _userEmail = user.email;
        Scaffold.of(context).showSnackBar(SnackBar(
                  content: Text('Succesfully created account'),
                  ));
        });
    } else {
      _success = false;
      Scaffold.of(context).showSnackBar(SnackBar(
                  content: Text('Account not created'),
                  ));
    }
  }
}
